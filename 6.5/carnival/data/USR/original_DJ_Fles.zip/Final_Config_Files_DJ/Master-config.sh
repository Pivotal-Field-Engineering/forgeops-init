#!/bin/bash -ex

ScriptStartingTime=${date}


BIN=/opt/opendj/bin
#Modify password Policy to allow encoded passwords
${BIN}/dsconfig set-password-policy-prop --policy-name "Default Password Policy" --set allow-pre-encoded-passwords:true --trustAll --port 4444 --bindDN "cn=directory manager" --bindPassword am4rgeR0ck --no-prompt
echo "Encoded Passwords now accepted";

#Input modified ldif
${BIN}/ldapmodify -D "cn=Directory Manager" -a -c -p 389 -w am4rgeR0ck -f /opt/adopextras/modified_final.ldif
echo "LDIF has been modified";

#Input updatedschema ldif
${BIN}/ldapmodify -D "cn=Directory Manager" -a -c -p 389 -w am4rgeR0ck -f /opt/adopextras/updatedschema_final.ldif
echo "Schema has been updated!"

#Input crew ldif
${BIN}/ldapmodify -D "cn=Directory Manager" -a -c -p 389 -w am4rgeR0ck -f /opt/adopextras/crew_final.ldif
echo "Crew members and groups of have been added!":

#Input guest ldif
${BIN}/ldapmodify -D "cn=Directory Manager" -a -c -p 389 -w am4rgeR0ck -f /opt/adopextras/guest_final.ldif
echo "Guests and groups of have been added!":


echo "OpenDJ configuration is complete!";

ScriptEndingTime=${date};

#printoutHowLongtheScriptTook "${ScriptStartingTime}" "${ScriptEndingTime}";
